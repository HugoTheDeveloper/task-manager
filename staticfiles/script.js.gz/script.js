<script>
    function setLanguage(language) {
        document.getElementById('language_input').value = language;
    }
</script>